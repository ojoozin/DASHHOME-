﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using EcoWatt;

namespace DASHHOME
{
    public partial class Form1 : Form
    {
        private Dictionary<string, double[]> dadosUsuarioAtual;
        private Dictionary<string, double[]> dadosUsuariosFicticios;

        public Form1()
        {
            InitializeComponent();
            InicializarCustomComponents();
        }

        private void InicializarCustomComponents()
        {
            dadosUsuarioAtual = new Dictionary<string, double[]>
            {
                { "Quarto 1", new double[] { 30, 28, 32, 33, 35, 34 } },
                { "Quarto 2", new double[] { 25, 27, 26, 29, 30, 28 } },
                { "Sala",     new double[] { 40, 45, 43, 47, 50, 49 } },
                { "Cozinha",  new double[] { 35, 38, 36, 39, 41, 40 } },
                { "Piscina",  new double[] { 50, 55, 53, 52, 56, 54 } },
            };

            dadosUsuariosFicticios = new Dictionary<string, double[]>
            {
                { "Usuário A", new double[] { 33, 30, 35, 36, 34, 33 } },
                { "Usuário B", new double[] { 28, 29, 27, 30, 31, 32 } },
                { "Usuário C", new double[] { 45, 48, 46, 50, 52, 51 } },
            };
        }

        private void AtualizarRanking(string comodo)
        {
            rankingListBox.Items.Clear();

            var ranking = dadosUsuariosFicticios
                .Select(u => new { Nome = u.Key, Media = u.Value.Average() })
                .OrderBy(u => u.Media);

            foreach (var usuario in ranking)
            {
                rankingListBox.Items.Add($"{usuario.Nome}: {usuario.Media:F2} kWh");
            }
        }

        private void ExibirGrafico(int mes, string comodo)
        {
            panelGastoContainer.Controls.Clear();

            Gasto grafico = new Gasto(mes, comodo); // <- agora com parâmetros corretos
            grafico.TopLevel = false;
            grafico.FormBorderStyle = FormBorderStyle.None;
            grafico.Dock = DockStyle.Fill;

            panelGastoContainer.Controls.Add(grafico);
            grafico.Show();
        }

        private void btnQuarto1_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Quarto 1");
            ExibirGrafico(5, "Quarto 1");
        }

        private void btnQuarto2_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Quarto 2");
            ExibirGrafico(5, "Quarto 2");
        }

        private void btnSala_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Sala");
            ExibirGrafico(5, "Sala");
        }

        private void btnCozinha_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Cozinha");
            ExibirGrafico(5, "Cozinha");
        }

        private void btnPiscina_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Piscina");
            ExibirGrafico(5, "Piscina");
        }

        private void rankingListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Ação ao selecionar item no ranking (se quiser)
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Deixe vazio para exibir apenas ao clicar no botão
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // Pode remover se não usar
        }

            private void btnPower_Click(object sender, EventArgs e)
        {
            this.Close(); // C#
        }
    }
    }

