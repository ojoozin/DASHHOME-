﻿namespace DASHHOME
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnQuarto1;
        private System.Windows.Forms.Button btnQuarto2;
        private System.Windows.Forms.Button btnSala;
        private System.Windows.Forms.Button btnCozinha;
        private System.Windows.Forms.Button btnPiscina;


        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnQuarto2 = new System.Windows.Forms.Button();
            this.btnSala = new System.Windows.Forms.Button();
            this.btnCozinha = new System.Windows.Forms.Button();
            this.btnPiscina = new System.Windows.Forms.Button();
            this.panelGastoContainer = new System.Windows.Forms.Panel();
            this.rankingListBox = new System.Windows.Forms.ListBox();
            this.btnToogle = new System.Windows.Forms.Button();
            this.panelSlide = new System.Windows.Forms.Panel();
            this.btnPower = new System.Windows.Forms.Button();
            this.btnQuarto1 = new System.Windows.Forms.Button();
            this.panelSlide.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnQuarto2
            // 
            this.btnQuarto2.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnQuarto2.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQuarto2.FlatAppearance.BorderSize = 0;
            this.btnQuarto2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuarto2.Font = new System.Drawing.Font("Cooper Black", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuarto2.ForeColor = System.Drawing.Color.White;
            this.btnQuarto2.Location = new System.Drawing.Point(0, 360);
            this.btnQuarto2.Name = "btnQuarto2";
            this.btnQuarto2.Size = new System.Drawing.Size(142, 56);
            this.btnQuarto2.TabIndex = 2;
            this.btnQuarto2.Text = "Quarto 2";
            this.btnQuarto2.UseVisualStyleBackColor = false;
            this.btnQuarto2.Click += new System.EventHandler(this.btnQuarto2_Click);
            // 
            // btnSala
            // 
            this.btnSala.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnSala.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSala.FlatAppearance.BorderSize = 0;
            this.btnSala.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSala.Font = new System.Drawing.Font("Cooper Black", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSala.ForeColor = System.Drawing.Color.White;
            this.btnSala.Location = new System.Drawing.Point(0, 184);
            this.btnSala.Name = "btnSala";
            this.btnSala.Size = new System.Drawing.Size(142, 59);
            this.btnSala.TabIndex = 3;
            this.btnSala.Text = "Sala";
            this.btnSala.UseVisualStyleBackColor = false;
            this.btnSala.Click += new System.EventHandler(this.btnSala_Click);
            // 
            // btnCozinha
            // 
            this.btnCozinha.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnCozinha.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCozinha.FlatAppearance.BorderSize = 0;
            this.btnCozinha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCozinha.Font = new System.Drawing.Font("Cooper Black", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCozinha.ForeColor = System.Drawing.Color.White;
            this.btnCozinha.Location = new System.Drawing.Point(0, 243);
            this.btnCozinha.Name = "btnCozinha";
            this.btnCozinha.Size = new System.Drawing.Size(142, 58);
            this.btnCozinha.TabIndex = 4;
            this.btnCozinha.Text = "Cozinha";
            this.btnCozinha.UseVisualStyleBackColor = false;
            this.btnCozinha.Click += new System.EventHandler(this.btnCozinha_Click);
            // 
            // btnPiscina
            // 
            this.btnPiscina.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnPiscina.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPiscina.FlatAppearance.BorderSize = 0;
            this.btnPiscina.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPiscina.Font = new System.Drawing.Font("Cooper Black", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPiscina.ForeColor = System.Drawing.Color.White;
            this.btnPiscina.Location = new System.Drawing.Point(0, 301);
            this.btnPiscina.Name = "btnPiscina";
            this.btnPiscina.Size = new System.Drawing.Size(142, 59);
            this.btnPiscina.TabIndex = 5;
            this.btnPiscina.Text = "Piscina";
            this.btnPiscina.UseVisualStyleBackColor = false;
            this.btnPiscina.Click += new System.EventHandler(this.btnPiscina_Click);
            // 
            // panelGastoContainer
            // 
            this.panelGastoContainer.Location = new System.Drawing.Point(163, 12);
            this.panelGastoContainer.Name = "panelGastoContainer";
            this.panelGastoContainer.Size = new System.Drawing.Size(695, 481);
            this.panelGastoContainer.TabIndex = 8;
            this.panelGastoContainer.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // rankingListBox
            // 
            this.rankingListBox.FormattingEnabled = true;
            this.rankingListBox.Location = new System.Drawing.Point(212, 499);
            this.rankingListBox.Name = "rankingListBox";
            this.rankingListBox.Size = new System.Drawing.Size(161, 56);
            this.rankingListBox.TabIndex = 7;
            this.rankingListBox.SelectedIndexChanged += new System.EventHandler(this.rankingListBox_SelectedIndexChanged);
            // 
            // btnToogle
            // 
            this.btnToogle.BackColor = System.Drawing.Color.Transparent;
            this.btnToogle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnToogle.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnToogle.FlatAppearance.BorderSize = 0;
            this.btnToogle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToogle.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnToogle.ForeColor = System.Drawing.Color.Transparent;
            this.btnToogle.Location = new System.Drawing.Point(0, 0);
            this.btnToogle.Name = "btnToogle";
            this.btnToogle.Size = new System.Drawing.Size(142, 129);
            this.btnToogle.TabIndex = 10;
            this.btnToogle.Text = "☰";
            this.btnToogle.UseVisualStyleBackColor = false;
            this.btnToogle.Click += new System.EventHandler(this.btnToogle_Click);
            // 
            // panelSlide
            // 
            this.panelSlide.BackColor = System.Drawing.SystemColors.Highlight;
            this.panelSlide.Controls.Add(this.btnPower);
            this.panelSlide.Controls.Add(this.btnQuarto2);
            this.panelSlide.Controls.Add(this.btnPiscina);
            this.panelSlide.Controls.Add(this.btnCozinha);
            this.panelSlide.Controls.Add(this.btnSala);
            this.panelSlide.Controls.Add(this.btnQuarto1);
            this.panelSlide.Controls.Add(this.btnToogle);
            this.panelSlide.Location = new System.Drawing.Point(1, -3);
            this.panelSlide.Name = "panelSlide";
            this.panelSlide.Size = new System.Drawing.Size(142, 570);
            this.panelSlide.TabIndex = 11;
            this.panelSlide.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSlide_Paint);
            // 
            // btnPower
            // 
            this.btnPower.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnPower.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPower.BackgroundImage")));
            this.btnPower.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPower.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.btnPower.FlatAppearance.BorderSize = 0;
            this.btnPower.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnPower.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnPower.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPower.ForeColor = System.Drawing.Color.Transparent;
            this.btnPower.Location = new System.Drawing.Point(11, 511);
            this.btnPower.Name = "btnPower";
            this.btnPower.Size = new System.Drawing.Size(48, 47);
            this.btnPower.TabIndex = 9;
            this.btnPower.UseVisualStyleBackColor = false;
            this.btnPower.Click += new System.EventHandler(this.btnPower_Click);
            // 
            // btnQuarto1
            // 
            this.btnQuarto1.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnQuarto1.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQuarto1.FlatAppearance.BorderSize = 0;
            this.btnQuarto1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuarto1.Font = new System.Drawing.Font("Cooper Black", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuarto1.ForeColor = System.Drawing.Color.White;
            this.btnQuarto1.Location = new System.Drawing.Point(0, 129);
            this.btnQuarto1.Name = "btnQuarto1";
            this.btnQuarto1.Size = new System.Drawing.Size(142, 55);
            this.btnQuarto1.TabIndex = 1;
            this.btnQuarto1.Text = "Quarto 1";
            this.btnQuarto1.UseVisualStyleBackColor = false;
            this.btnQuarto1.Click += new System.EventHandler(this.btnQuarto1_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(880, 576);
            this.Controls.Add(this.panelSlide);
            this.Controls.Add(this.panelGastoContainer);
            this.Controls.Add(this.rankingListBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "DashHome";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelSlide.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelGastoContainer;
        private System.Windows.Forms.ListBox rankingListBox;
        private System.Windows.Forms.Button btnPower;
        private System.Windows.Forms.Button btnToogle;
        private System.Windows.Forms.Panel panelSlide;
    }
}
