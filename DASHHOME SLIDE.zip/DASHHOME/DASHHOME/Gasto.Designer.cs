﻿using System.Windows.Forms;

namespace EcoWatt
{
    partial class Gasto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            SATAUiFramework.BorderRadius borderRadius1 = new SATAUiFramework.BorderRadius();
            SATAUiFramework.BorderRadius borderRadius2 = new SATAUiFramework.BorderRadius();
            SATAUiFramework.BorderRadius borderRadius3 = new SATAUiFramework.BorderRadius();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet1 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet2 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet3 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet4 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet5 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet6 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet7 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet8 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet9 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet10 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet11 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet12 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet13 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet14 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet15 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet16 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet17 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet18 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet19 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet20 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet21 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet22 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet23 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet24 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet25 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet26 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet27 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet28 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet29 = new FrameworkTest.Charts.SATALineChart.DataSet();
            FrameworkTest.Charts.SATALineChart.DataSet dataSet30 = new FrameworkTest.Charts.SATALineChart.DataSet();
            SATAUiFramework.BorderRadius borderRadius4 = new SATAUiFramework.BorderRadius();
            this.sataEllipseControl1 = new SATAUiFramework.Controls.SATAEllipseControl();
            this.sataPanel2 = new SATAUiFramework.SATAPanel();
            this.sataPanel5 = new SATAUiFramework.SATAPanel();
            this.sataPanel3 = new SATAUiFramework.SATAPanel();
            this.Gasto_grafSata = new FrameworkTest.Charts.SATALineChart();
            this.sataPanel4 = new SATAUiFramework.SATAPanel();
            this.proximoMes_bnt = new FrameworkTest.SATAButton();
            this.VoltaMes_bnt = new FrameworkTest.SATAButton();
            this.mes_label = new System.Windows.Forms.Label();
            this.sataPanel2.SuspendLayout();
            this.sataPanel3.SuspendLayout();
            this.sataPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // sataEllipseControl1
            // 
            this.sataEllipseControl1.CornerRadius = 30;
            this.sataEllipseControl1.TargetControl = this;
            // 
            // sataPanel2
            // 
            this.sataPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(228)))), ((int)(((byte)(235)))));
            this.sataPanel2.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(228)))), ((int)(((byte)(235)))));
            this.sataPanel2.BorderColor = System.Drawing.Color.Black;
            borderRadius1.BottomLeft = 10;
            borderRadius1.BottomRight = 10;
            borderRadius1.TopLeft = 10;
            borderRadius1.TopRight = 10;
            this.sataPanel2.BorderRadius = borderRadius1;
            this.sataPanel2.BorderThickness = 0;
            this.sataPanel2.Controls.Add(this.sataPanel5);
            this.sataPanel2.Controls.Add(this.sataPanel3);
            this.sataPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sataPanel2.Location = new System.Drawing.Point(0, 0);
            this.sataPanel2.Name = "sataPanel2";
            this.sataPanel2.Size = new System.Drawing.Size(697, 514);
            this.sataPanel2.TabIndex = 1;
            // 
            // sataPanel5
            // 
            this.sataPanel5.BackColor = System.Drawing.SystemColors.Control;
            this.sataPanel5.BackColor2 = System.Drawing.SystemColors.Control;
            this.sataPanel5.BorderColor = System.Drawing.Color.Black;
            borderRadius2.BottomLeft = 10;
            borderRadius2.BottomRight = 10;
            borderRadius2.TopLeft = 10;
            borderRadius2.TopRight = 10;
            this.sataPanel5.BorderRadius = borderRadius2;
            this.sataPanel5.BorderThickness = 0;
            this.sataPanel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sataPanel5.Location = new System.Drawing.Point(0, 504);
            this.sataPanel5.Name = "sataPanel5";
            this.sataPanel5.Padding = new System.Windows.Forms.Padding(10);
            this.sataPanel5.Size = new System.Drawing.Size(697, 10);
            this.sataPanel5.TabIndex = 3;
            // 
            // sataPanel3
            // 
            this.sataPanel3.AutoScroll = true;
            this.sataPanel3.BackColor = System.Drawing.SystemColors.Control;
            this.sataPanel3.BackColor2 = System.Drawing.SystemColors.Control;
            this.sataPanel3.BorderColor = System.Drawing.Color.Black;
            borderRadius3.BottomLeft = 10;
            borderRadius3.BottomRight = 10;
            borderRadius3.TopLeft = 10;
            borderRadius3.TopRight = 10;
            this.sataPanel3.BorderRadius = borderRadius3;
            this.sataPanel3.BorderThickness = 0;
            this.sataPanel3.Controls.Add(this.Gasto_grafSata);
            this.sataPanel3.Controls.Add(this.sataPanel4);
            this.sataPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sataPanel3.Location = new System.Drawing.Point(0, 0);
            this.sataPanel3.Name = "sataPanel3";
            this.sataPanel3.Size = new System.Drawing.Size(697, 514);
            this.sataPanel3.TabIndex = 3;
            this.sataPanel3.Paint += new System.Windows.Forms.PaintEventHandler(this.sataPanel3_Paint);
            // 
            // Gasto_grafSata
            // 
            this.Gasto_grafSata.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Gasto_grafSata.AutoMaxValue = false;
            this.Gasto_grafSata.AutoScroll = true;
            this.Gasto_grafSata.AutoSize = true;
            this.Gasto_grafSata.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.Gasto_grafSata.AxisColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(228)))), ((int)(((byte)(235)))));
            this.Gasto_grafSata.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Gasto_grafSata.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Gasto_grafSata.CausesValidation = false;
            this.Gasto_grafSata.ChartPadding = 40;
            this.Gasto_grafSata.CustomXAxis = new string[0];
            dataSet1.Label = "Sample Dataset 1";
            dataSet1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet1.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet1.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet2.Label = "Sample Dataset 2";
            dataSet2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet2.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet2.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet3.Label = "Sample Dataset 1";
            dataSet3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet3.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet3.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet4.Label = "Sample Dataset 2";
            dataSet4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet4.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet4.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet5.Label = "Sample Dataset 1";
            dataSet5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet5.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet5.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet6.Label = "Sample Dataset 2";
            dataSet6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet6.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet6.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet7.Label = "Sample Dataset 1";
            dataSet7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet7.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet7.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet8.Label = "Sample Dataset 2";
            dataSet8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet8.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet8.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet9.Label = "Sample Dataset 1";
            dataSet9.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet9.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet9.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet10.Label = "Sample Dataset 2";
            dataSet10.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet10.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet10.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet11.Label = "Sample Dataset 1";
            dataSet11.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet11.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet11.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet12.Label = "Sample Dataset 2";
            dataSet12.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet12.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet12.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet13.Label = "Sample Dataset 1";
            dataSet13.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet13.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet13.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet14.Label = "Sample Dataset 2";
            dataSet14.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet14.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet14.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet15.Label = "Sample Dataset 1";
            dataSet15.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet15.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet15.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet16.Label = "Sample Dataset 2";
            dataSet16.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet16.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet16.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet17.Label = "Sample Dataset 1";
            dataSet17.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet17.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet17.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet18.Label = "Sample Dataset 2";
            dataSet18.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet18.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet18.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet19.Label = "Sample Dataset 1";
            dataSet19.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet19.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet19.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet20.Label = "Sample Dataset 2";
            dataSet20.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet20.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet20.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet21.Label = "Sample Dataset 1";
            dataSet21.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet21.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet21.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet22.Label = "Sample Dataset 2";
            dataSet22.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet22.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet22.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet23.Label = "Sample Dataset 1";
            dataSet23.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet23.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet23.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet24.Label = "Sample Dataset 2";
            dataSet24.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet24.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet24.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet25.Label = "Sample Dataset 1";
            dataSet25.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet25.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet25.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet26.Label = "Sample Dataset 2";
            dataSet26.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet26.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet26.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet27.Label = "Sample Dataset 1";
            dataSet27.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet27.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet27.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet28.Label = "Sample Dataset 2";
            dataSet28.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet28.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet28.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            dataSet29.Label = "Sample Dataset 1";
            dataSet29.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet29.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(79)))), ((int)(((byte)(165)))));
            dataSet29.Points = new float[] {
        105F,
        65F,
        80F,
        120F,
        135F,
        65F,
        30F};
            dataSet30.Label = "Sample Dataset 2";
            dataSet30.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet30.PointColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(160)))), ((int)(((byte)(1)))));
            dataSet30.Points = new float[] {
        80F,
        90F,
        70F,
        100F,
        110F,
        50F,
        40F};
            this.Gasto_grafSata.DataSets.Add(dataSet1);
            this.Gasto_grafSata.DataSets.Add(dataSet2);
            this.Gasto_grafSata.DataSets.Add(dataSet3);
            this.Gasto_grafSata.DataSets.Add(dataSet4);
            this.Gasto_grafSata.DataSets.Add(dataSet5);
            this.Gasto_grafSata.DataSets.Add(dataSet6);
            this.Gasto_grafSata.DataSets.Add(dataSet7);
            this.Gasto_grafSata.DataSets.Add(dataSet8);
            this.Gasto_grafSata.DataSets.Add(dataSet9);
            this.Gasto_grafSata.DataSets.Add(dataSet10);
            this.Gasto_grafSata.DataSets.Add(dataSet11);
            this.Gasto_grafSata.DataSets.Add(dataSet12);
            this.Gasto_grafSata.DataSets.Add(dataSet13);
            this.Gasto_grafSata.DataSets.Add(dataSet14);
            this.Gasto_grafSata.DataSets.Add(dataSet15);
            this.Gasto_grafSata.DataSets.Add(dataSet16);
            this.Gasto_grafSata.DataSets.Add(dataSet17);
            this.Gasto_grafSata.DataSets.Add(dataSet18);
            this.Gasto_grafSata.DataSets.Add(dataSet19);
            this.Gasto_grafSata.DataSets.Add(dataSet20);
            this.Gasto_grafSata.DataSets.Add(dataSet21);
            this.Gasto_grafSata.DataSets.Add(dataSet22);
            this.Gasto_grafSata.DataSets.Add(dataSet23);
            this.Gasto_grafSata.DataSets.Add(dataSet24);
            this.Gasto_grafSata.DataSets.Add(dataSet25);
            this.Gasto_grafSata.DataSets.Add(dataSet26);
            this.Gasto_grafSata.DataSets.Add(dataSet27);
            this.Gasto_grafSata.DataSets.Add(dataSet28);
            this.Gasto_grafSata.DataSets.Add(dataSet29);
            this.Gasto_grafSata.DataSets.Add(dataSet30);
            this.Gasto_grafSata.DayColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(228)))), ((int)(((byte)(235)))));
            this.Gasto_grafSata.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Gasto_grafSata.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(228)))), ((int)(((byte)(235)))));
            this.Gasto_grafSata.GradientBackground = false;
            this.Gasto_grafSata.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(228)))), ((int)(((byte)(235)))));
            this.Gasto_grafSata.LabelPosition = FrameworkTest.Charts.LabelPosition.Top;
            this.Gasto_grafSata.Location = new System.Drawing.Point(101, 105);
            this.Gasto_grafSata.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Gasto_grafSata.MaxValue = 30F;
            this.Gasto_grafSata.Name = "Gasto_grafSata";
            this.Gasto_grafSata.ShortDates = true;
            this.Gasto_grafSata.ShowGrid = true;
            this.Gasto_grafSata.Size = new System.Drawing.Size(497, 377);
            this.Gasto_grafSata.TabIndex = 0;
            this.Gasto_grafSata.UseBezier = true;
            this.Gasto_grafSata.UsePercent = false;
            this.Gasto_grafSata.Load += new System.EventHandler(this.Gasto_grafSata_Load);
            // 
            // sataPanel4
            // 
            this.sataPanel4.BackColor2 = System.Drawing.SystemColors.Control;
            this.sataPanel4.BorderColor = System.Drawing.Color.Black;
            borderRadius4.BottomLeft = 10;
            borderRadius4.BottomRight = 10;
            borderRadius4.TopLeft = 10;
            borderRadius4.TopRight = 10;
            this.sataPanel4.BorderRadius = borderRadius4;
            this.sataPanel4.BorderThickness = 0;
            this.sataPanel4.Controls.Add(this.proximoMes_bnt);
            this.sataPanel4.Controls.Add(this.VoltaMes_bnt);
            this.sataPanel4.Controls.Add(this.mes_label);
            this.sataPanel4.Location = new System.Drawing.Point(101, 31);
            this.sataPanel4.Name = "sataPanel4";
            this.sataPanel4.Size = new System.Drawing.Size(482, 55);
            this.sataPanel4.TabIndex = 3;
            this.sataPanel4.Paint += new System.Windows.Forms.PaintEventHandler(this.sataPanel4_Paint);
            // 
            // proximoMes_bnt
            // 
            this.proximoMes_bnt.ButtonText = ">";
            this.proximoMes_bnt.CheckedBackground = System.Drawing.Color.DodgerBlue;
            this.proximoMes_bnt.CheckedForeColor = System.Drawing.Color.White;
            this.proximoMes_bnt.CheckedImageTint = System.Drawing.Color.White;
            this.proximoMes_bnt.CheckedOutline = System.Drawing.Color.DodgerBlue;
            this.proximoMes_bnt.CustomDialogResult = System.Windows.Forms.DialogResult.None;
            this.proximoMes_bnt.Dock = System.Windows.Forms.DockStyle.Right;
            this.proximoMes_bnt.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.proximoMes_bnt.HoverBackground = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.proximoMes_bnt.HoverForeColor = System.Drawing.Color.White;
            this.proximoMes_bnt.HoverImage = null;
            this.proximoMes_bnt.HoverImageTint = System.Drawing.Color.White;
            this.proximoMes_bnt.HoverOutline = System.Drawing.Color.Empty;
            this.proximoMes_bnt.Image = null;
            this.proximoMes_bnt.ImageAutoCenter = true;
            this.proximoMes_bnt.ImageExpand = new System.Drawing.Point(0, 0);
            this.proximoMes_bnt.ImageOffset = new System.Drawing.Point(0, 0);
            this.proximoMes_bnt.ImageTint = System.Drawing.Color.White;
            this.proximoMes_bnt.IsToggleButton = false;
            this.proximoMes_bnt.IsToggled = false;
            this.proximoMes_bnt.Location = new System.Drawing.Point(385, 0);
            this.proximoMes_bnt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.proximoMes_bnt.Name = "proximoMes_bnt";
            this.proximoMes_bnt.NormalBackground = System.Drawing.SystemColors.Highlight;
            this.proximoMes_bnt.NormalForeColor = System.Drawing.Color.White;
            this.proximoMes_bnt.NormalOutline = System.Drawing.Color.Empty;
            this.proximoMes_bnt.OutlineThickness = 2F;
            this.proximoMes_bnt.PressedBackground = System.Drawing.Color.RoyalBlue;
            this.proximoMes_bnt.PressedForeColor = System.Drawing.Color.White;
            this.proximoMes_bnt.PressedImageTint = System.Drawing.Color.White;
            this.proximoMes_bnt.PressedOutline = System.Drawing.Color.Empty;
            this.proximoMes_bnt.Rounding = new System.Windows.Forms.Padding(5);
            this.proximoMes_bnt.Size = new System.Drawing.Size(97, 55);
            this.proximoMes_bnt.TabIndex = 2;
            this.proximoMes_bnt.TextAutoCenter = true;
            this.proximoMes_bnt.TextOffset = new System.Drawing.Point(0, 0);
            this.proximoMes_bnt.Click += new System.EventHandler(this.proximoMes_bnt_Click);
            // 
            // VoltaMes_bnt
            // 
            this.VoltaMes_bnt.ButtonText = "<";
            this.VoltaMes_bnt.CheckedBackground = System.Drawing.Color.SteelBlue;
            this.VoltaMes_bnt.CheckedForeColor = System.Drawing.Color.White;
            this.VoltaMes_bnt.CheckedImageTint = System.Drawing.Color.White;
            this.VoltaMes_bnt.CheckedOutline = System.Drawing.Color.SteelBlue;
            this.VoltaMes_bnt.CustomDialogResult = System.Windows.Forms.DialogResult.None;
            this.VoltaMes_bnt.Dock = System.Windows.Forms.DockStyle.Left;
            this.VoltaMes_bnt.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.VoltaMes_bnt.HoverBackground = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.VoltaMes_bnt.HoverForeColor = System.Drawing.Color.White;
            this.VoltaMes_bnt.HoverImage = null;
            this.VoltaMes_bnt.HoverImageTint = System.Drawing.Color.White;
            this.VoltaMes_bnt.HoverOutline = System.Drawing.Color.Empty;
            this.VoltaMes_bnt.Image = null;
            this.VoltaMes_bnt.ImageAutoCenter = true;
            this.VoltaMes_bnt.ImageExpand = new System.Drawing.Point(0, 0);
            this.VoltaMes_bnt.ImageOffset = new System.Drawing.Point(0, 0);
            this.VoltaMes_bnt.ImageTint = System.Drawing.Color.White;
            this.VoltaMes_bnt.IsToggleButton = false;
            this.VoltaMes_bnt.IsToggled = false;
            this.VoltaMes_bnt.Location = new System.Drawing.Point(0, 0);
            this.VoltaMes_bnt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.VoltaMes_bnt.Name = "VoltaMes_bnt";
            this.VoltaMes_bnt.NormalBackground = System.Drawing.SystemColors.Highlight;
            this.VoltaMes_bnt.NormalForeColor = System.Drawing.Color.White;
            this.VoltaMes_bnt.NormalOutline = System.Drawing.Color.Empty;
            this.VoltaMes_bnt.OutlineThickness = 2F;
            this.VoltaMes_bnt.PressedBackground = System.Drawing.Color.RoyalBlue;
            this.VoltaMes_bnt.PressedForeColor = System.Drawing.Color.White;
            this.VoltaMes_bnt.PressedImageTint = System.Drawing.Color.White;
            this.VoltaMes_bnt.PressedOutline = System.Drawing.Color.Empty;
            this.VoltaMes_bnt.Rounding = new System.Windows.Forms.Padding(5);
            this.VoltaMes_bnt.Size = new System.Drawing.Size(98, 55);
            this.VoltaMes_bnt.TabIndex = 1;
            this.VoltaMes_bnt.TextAutoCenter = true;
            this.VoltaMes_bnt.TextOffset = new System.Drawing.Point(0, 0);
            this.VoltaMes_bnt.Click += new System.EventHandler(this.VoltaMes_bnt_Click);
            // 
            // mes_label
            // 
            this.mes_label.AutoSize = true;
            this.mes_label.BackColor = System.Drawing.Color.Transparent;
            this.mes_label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mes_label.Font = new System.Drawing.Font("Cooper Black", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mes_label.ForeColor = System.Drawing.Color.Black;
            this.mes_label.Location = new System.Drawing.Point(187, 16);
            this.mes_label.Name = "mes_label";
            this.mes_label.Size = new System.Drawing.Size(73, 24);
            this.mes_label.TabIndex = 3;
            this.mes_label.Text = "label1";
            this.mes_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Gasto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(697, 514);
            this.Controls.Add(this.sataPanel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Gasto";
            this.Text = "Gasto";
            this.sataPanel2.ResumeLayout(false);
            this.sataPanel3.ResumeLayout(false);
            this.sataPanel3.PerformLayout();
            this.sataPanel4.ResumeLayout(false);
            this.sataPanel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private SATAUiFramework.Controls.SATAEllipseControl sataEllipseControl1;
        private SATAUiFramework.SATAPanel sataPanel2;
        private FrameworkTest.Charts.SATALineChart Gasto_grafSata;
        private FrameworkTest.SATAButton proximoMes_bnt;
        private FrameworkTest.SATAButton VoltaMes_bnt;
        private SATAUiFramework.SATAPanel sataPanel3;
        private SATAUiFramework.SATAPanel sataPanel4;
        private SATAUiFramework.SATAPanel sataPanel5;
        private System.Windows.Forms.Label mes_label;
    }
}