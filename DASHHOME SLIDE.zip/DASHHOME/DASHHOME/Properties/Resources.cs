﻿namespace DASHHOME.Properties
{
    internal class Resources
    {
    }
}