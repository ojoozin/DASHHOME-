﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using EcoWatt;

namespace DASHHOME
{
    public partial class Form1 : Form
    {
        private Dictionary<string, double[]> dadosUsuarioAtual;
        private Dictionary<string, double[]> dadosUsuariosFicticios;
        private bool slideExpand = true;
        private int slideMaxWidth = 200;
        private int slideMinWidth = 80;
        private Timer slideTimer = new Timer();

        public Form1()
        {
            InitializeComponent();
            InicializarCustomComponents();

            slideTimer.Interval = 10;
            slideTimer.Tick += SlideTimer_Tick;
            AtualizarIconesSlide(panelSlide.Width <= slideMinWidth);
        }

        private void InicializarCustomComponents()
        {
            dadosUsuarioAtual = new Dictionary<string, double[]>
            {
                { "Quarto 1", new double[] { 30, 28, 32, 33, 35, 34 } },
                { "Quarto 2", new double[] { 25, 27, 26, 29, 30, 28 } },
                { "Sala",     new double[] { 40, 45, 43, 47, 50, 49 } },
                { "Cozinha",  new double[] { 35, 38, 36, 39, 41, 40 } },
                { "Piscina",  new double[] { 50, 55, 53, 52, 56, 54 } },
            };

            dadosUsuariosFicticios = new Dictionary<string, double[]>
            {
                { "Usuário A", new double[] { 33, 30, 35, 36, 34, 33 } },
                { "Usuário B", new double[] { 28, 29, 27, 30, 31, 32 } },
                { "Usuário C", new double[] { 45, 48, 46, 50, 52, 51 } },
            };
        }

        private void AtualizarRanking(string comodo)
        {
            rankingListBox.Items.Clear();

            var ranking = dadosUsuariosFicticios
                .Select(u => new { Nome = u.Key, Media = u.Value.Average() })
                .OrderBy(u => u.Media);

            foreach (var usuario in ranking)
            {
                rankingListBox.Items.Add($"{usuario.Nome}: {usuario.Media:F2} kWh");
            }
        }

        private void ExibirGrafico(int mes, string comodo)
        {
            panelGastoContainer.Controls.Clear();

            Gasto grafico = new Gasto(mes, comodo);
            grafico.TopLevel = false;
            grafico.FormBorderStyle = FormBorderStyle.None;
            grafico.Dock = DockStyle.Fill;

            panelGastoContainer.Controls.Add(grafico);
            grafico.Show();
        }

        private void btnQuarto1_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Quarto 1");
            ExibirGrafico(5, "Quarto 1");
        }

        private void btnQuarto2_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Quarto 2");
            ExibirGrafico(5, "Quarto 2");
        }

        private void btnSala_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Sala");
            ExibirGrafico(5, "Sala");
        }

        private void btnCozinha_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Cozinha");
            ExibirGrafico(5, "Cozinha");
        }

        private void btnPiscina_Click(object sender, EventArgs e)
        {
            AtualizarRanking("Piscina");
            ExibirGrafico(5, "Piscina");
        }

        private void rankingListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Evento opcional
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Inicialização se necessário
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // Pode ser removido
        }

        private void btnPower_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnToogle_Click(object sender, EventArgs e)
        {
            slideTimer.Start();
        }

        private void panelSlide_Paint(object sender, PaintEventArgs e)
        {
        }

        private void AtualizarIconesSlide(bool minimizado)
        {
            string basePath = Path.Combine(Application.StartupPath, "Resources");

            if (minimizado)
            {


                btnToogle.ForeColor = Color.Black;

                Size iconSize = new Size(32, 32); 

                btnQuarto1.Text = "";
                btnQuarto1.Image = new Bitmap(Image.FromFile(Path.Combine(basePath, "ico_quarto1.png")), iconSize);
                btnQuarto1.ImageAlign = ContentAlignment.MiddleCenter;

                btnQuarto2.Text = "";
                btnQuarto2.Image = new Bitmap(Image.FromFile(Path.Combine(basePath, "ico_quarto2.png")), iconSize);
                btnQuarto2.ImageAlign = ContentAlignment.MiddleCenter;

                btnSala.Text = "";
                btnSala.Image = new Bitmap(Image.FromFile(Path.Combine(basePath, "ico_sala.png")), iconSize);
                btnSala.ImageAlign = ContentAlignment.MiddleCenter;

                btnCozinha.Text = "";
                btnCozinha.Image = new Bitmap(Image.FromFile(Path.Combine(basePath, "ico_cozinha.png")), iconSize);
                btnCozinha.ImageAlign = ContentAlignment.MiddleCenter;

                btnPiscina.Text = "";
                btnPiscina.Image = new Bitmap(Image.FromFile(Path.Combine(basePath, "ico_piscina.png")), iconSize);
                btnPiscina.ImageAlign = ContentAlignment.MiddleCenter;
            }
            else
            {
                btnToogle.ForeColor = Color.White;

                btnQuarto1.Text = "Quarto 1";
                btnQuarto1.Image = null;

                btnQuarto2.Text = "Quarto 2";
                btnQuarto2.Image = null;

                btnSala.Text = "Sala";
                btnSala.Image = null;

                btnCozinha.Text = "Cozinha";
                btnCozinha.Image = null;

                btnPiscina.Text = "Piscina";
                btnPiscina.Image = null;
            }
        }



        private void SlideTimer_Tick(object sender, EventArgs e)
        {
            if (slideExpand)
            {
                panelSlide.Width -= 10;
                if (panelSlide.Width <= slideMinWidth)
                {
                    slideExpand = false;
                    slideTimer.Stop();
                    AtualizarIconesSlide(true); // minimizado
                }
            }
            else
            {
                panelSlide.Width += 10;
                if (panelSlide.Width >= slideMaxWidth)
                {
                    slideExpand = true;
                    slideTimer.Stop();
                    AtualizarIconesSlide(false); // expandido
                }
            }
        }
    }
}
